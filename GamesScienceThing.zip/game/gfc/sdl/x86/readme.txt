***************
** LIB Files **
***************


SDL Project
-----------
SDL.lib
SDL_main.lib


SDL-GFX
-------
sdl_GFX.lib


SDL_image Project
-----------------
SDL_image.lib


SDL_mixer Project
-----------------
SDL_mixer.lib


SDL_net Project
---------------
SDL_net.lib


SDL_ttf Project
---------------
SDL_ttf.lib


***************
** DLL Files **
***************


SDL Project
-----------
SDL.dll


SDL_gfx Project
---------------
SDL_gfx.dll


SDL_image Project
-----------------
SDL_image.dll
libjpeg-8.dll
libpng15-15.dll
libtiff-5.dll
libwebp-2.dll
zlib1.dll


SDL_mixer Project
-----------------
SDL_mixer.dll
libogg-0.dll
libvorbis-0.dll
libvorbisfile-3.dll
smpeg.dll
libFLAC-8.dll
libmikmod-2.dll


SDL_net Project
---------------
SDL_net.dll


SDL_ttf Project
---------------
SDL_ttf.h
libfreetype-6.dll


*****************
** Other Files **
*****************


Additional File in This Directory
---------------------------------
Arial.TTF - a sample TTF font



